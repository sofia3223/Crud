package co.edu.eu.actividad.model;

public class UserDAO {

}
